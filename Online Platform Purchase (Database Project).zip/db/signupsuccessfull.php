<h1>Sign up successful!</h1>
<h2>Please login to your account now</h2>